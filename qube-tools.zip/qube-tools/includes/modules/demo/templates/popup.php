<div id="qube-tools-demo-popup-wrap">
    <div class="qube-tools-demo-popup-container">
        <div class="qube-tools-demo-popup-content-wrap">
            <div class="qube-tools-demo-popup-content-inner">
                <a href="#" class="qube-tools-demo-popup-close">×</a>
                <div id="qube-tools-demo-popup-content"></div>
            </div>
        </div>
    </div>
    <div class="qube-tools-demo-popup-overlay"></div>
</div>