<?php

namespace Qube_Tools\Includes;

class Ajax
{

    public function __construct()
    {

    }


}
