=== Qube Tools ===
Contributors: qubethemes
Tags: demo import, tools, elementor template library
Requires at least: 4.7
Tested up to: 5.8
Stable tag: 1.0.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Extend Qubethemes's theme feature & one click demo importer

== Description ==

Extend Qubethemes's theme feature & one click demo importer



== Installation ==

1. Install the plugin either via the WordPress.org plugin directory, or by uploading the files to your server (in the /wp-content/plugins/ directory).
2. Activate the Mantra Audience plugin through the 'Plugins' menu in WordPress.


== Changelog ==

= 1.0.0 | 2021/08/01 =
* Initial release
